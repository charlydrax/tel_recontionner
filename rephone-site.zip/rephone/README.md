# RePhone — Site Fictif de Test 🧪

> ⚠️ **SITE DE DÉMONSTRATION UNIQUEMENT** — Créé pour tester des extensions de sécurité de paiement. Aucune transaction réelle. Aucune donnée n'est collectée ou transmise.

## Structure du projet

```
rephone/
├── index.html          → Page d'accueil
├── catalogue.html      → Catalogue avec filtres
├── produit.html        → Fiche produit (chargée via ?id=N)
├── panier.html         → Panier
├── paiement.html       → Page de paiement (page clé pour les tests)
├── css/
│   └── style.css       → Feuille de style complète
└── js/
    ├── data.js         → 12 produits fictifs + avis
    ├── app.js          → Fonctions globales + panier (sessionStorage)
    ├── catalogue.js    → Filtres marque/grade/prix
    ├── product.js      → Page produit dynamique
    ├── panier.js       → Page panier
    └── checkout.js     → Formulaire de paiement fictif
```

## Déploiement sur GitHub Pages

1. Créer un repo GitHub (ex: `rephone-test`)
2. Pousser tous les fichiers à la racine
3. Settings → Pages → Source: `main` / `root`
4. Ton site sera sur : `https://[username].github.io/rephone-test/`

## Fonctionnalités

- 🛍️ **Catalogue** de 12 téléphones (iPhone, Samsung, Pixel) avec filtres
- 🔍 **Fiche produit** avec specs, batterie, grade, avis
- 🛒 **Panier** fonctionnel (sessionStorage — données effacées à la fermeture)
- 💳 **Page paiement fictif** avec :
  - Formulaire livraison
  - Choix mode de livraison (3 options)
  - Paiement par carte (avec aperçu dynamique), PayPal fictif, Apple Pay fictif
  - Validation basique côté client
  - Modal de confirmation fictive

## Notes de sécurité

- ❌ Pas de backend
- ❌ Pas de base de données
- ❌ Aucune donnée saisie n'est envoyée nulle part
- ✅ SessionStorage uniquement (effacé à la fermeture du navigateur)
- ✅ Avertissement visible sur toutes les pages

## Utilisation pour tester une extension

La page `paiement.html` contient :
- Un formulaire de carte bancaire (numéro, nom, expiration, CVV)
- Un formulaire email PayPal
- Des indicateurs de sécurité fictifs (`🔒 SSL simulé`)
- Des badges de confiance factices

C'est la page idéale pour tester la détection de formulaires de paiement par ton extension.
